package Test0415_Night;

import javax.swing.JPanel;

public class OrderPanelCollection {
	
	public int yPosition;
	public JPanel orderPanel;
}
